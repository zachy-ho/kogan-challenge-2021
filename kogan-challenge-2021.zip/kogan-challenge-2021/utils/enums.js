const ProductsEnum = Object.freeze({
  AIR_CONDITIONER: 'Air Conditioners',
});

module.exports = ProductsEnum;
